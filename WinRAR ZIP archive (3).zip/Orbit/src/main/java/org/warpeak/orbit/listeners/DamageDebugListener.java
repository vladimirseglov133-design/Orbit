package org.warpeak.orbit.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.warpeak.orbit.Orbit;
import org.warpeak.orbit.duel.DuelManager;

/**
 * MONITOR = выполняется САМЫМ ПОСЛЕДНИМ, после абсолютно всех остальных плагинов и листенеров.
 * Показывает ИТОГОВОЕ состояние события — было ли оно отменено, и если да, то что известно
 * о причине на момент выполнения (способности жертвы).
 */
public class DamageDebugListener implements Listener {

    private final DuelManager duelManager;

    public DamageDebugListener(DuelManager duelManager) {
        this.duelManager = duelManager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamageMonitor(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!duelManager.isInDuel(victim) || !duelManager.isInDuel(attacker)) return;

        var data = Orbit.get().getAbilityManager().getData(victim);
        String tier4 = (data != null && data.tier4 != null) ? data.tier4.name() : "none";
        boolean instinctActive = data != null && data.ultraInstinctActive;

        Orbit.get().getLogger().info("[DamageDebug] " + attacker.getName() + " -> " + victim.getName()
                + " | cancelled=" + event.isCancelled()
                + " | finalDamage=" + event.getFinalDamage()
                + " | victimTier4=" + tier4
                + " | victimInstinctActive=" + instinctActive);
    }
}